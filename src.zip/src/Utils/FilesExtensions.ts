
export enum CodeFilesExtensions{
    java = 'java',
    ts = 'ts',
    js ='js',
    cs ='cs',
    cpp = 'cpp',
    c = 'c',
    py = 'py',  
}

export enum MediaFilesExtsensions{
    gif = 'gif',
    png = 'png',
    jpg = 'jpg'
}