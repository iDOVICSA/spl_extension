export enum IgnoredFolders{
    buid = 'build',
    node_modules = 'node_modules',
    out = 'out',
    test = 'test'
}

